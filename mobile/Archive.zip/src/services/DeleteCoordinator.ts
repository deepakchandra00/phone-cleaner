import * as MediaLibrary from "expo-media-library/legacy";
import * as FileSystem from "expo-file-system/legacy";
import { AndroidStorage, SAFBridge } from "android-storage";
import { StorageIndexService } from "@/db/StorageIndexService";
import { StorageVerifier } from "@/services/StorageVerifier";
import type { StorageItem, DeleteStrategy } from "@/db/schema";

export interface DeleteResult {
  requestedCount: number;
  deletedCount: number;
  freedBytes: number;
  failedCount: number;
  permissionBlockedCount: number;
}

type DeleteListener = (deletedIds: string[]) => void;

class DeleteCoordinatorImpl {
  private listeners = new Set<DeleteListener>();

  public addListener(listener: DeleteListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(deletedIds: string[]): void {
    for (const listener of this.listeners) {
      try {
        listener(deletedIds);
      } catch (err) {
        console.warn("[DeleteCoordinator] Listener error:", err);
      }
    }
  }

  /**
   * Deletes a single storage item from the real Android storage,
   * then purges it from the SQLite index upon physical verification.
   */
  public async deleteItem(item: StorageItem): Promise<boolean> {
    const res = await this.deleteMany([item.id]);
    return res.deletedCount > 0;
  }

  /**
   * Batch deletes multiple items by IDs.
   * Dispatches each item strictly according to its DeleteStrategy.
   * Never blindly falls back to java.io.File.delete() for MediaStore assets.
   * Physically verifies absence on disk/ContentResolver before marking as deleted.
   */
  public async deleteMany(ids: string[]): Promise<DeleteResult> {
    if (ids.length === 0) {
      return { requestedCount: 0, deletedCount: 0, freedBytes: 0, failedCount: 0, permissionBlockedCount: 0 };
    }

    const items = StorageIndexService.getItemsByIds(ids);
    if (items.length === 0) {
      // If records were already removed from DB, verify they are purged
      StorageIndexService.deleteItemsByIds(ids);
      this.notify(ids);
      return { requestedCount: ids.length, deletedCount: ids.length, freedBytes: 0, failedCount: 0, permissionBlockedCount: 0 };
    }

    const mediaStoreItems: StorageItem[] = [];
    const documentUriItems: StorageItem[] = [];
    const filesystemItems: StorageItem[] = [];
    const manageExternalItems: StorageItem[] = [];
    const unsupportedItems: StorageItem[] = [];

    for (const item of items) {
      const isExternalPath = Boolean(item.path && (item.path.startsWith("/storage/") || item.path.startsWith("/sdcard/")));
      const isWhatsApp = item.source === "whatsapp" || Boolean(item.path && item.path.includes("com.whatsapp"));
      const isExternalManaged = isWhatsApp || (isExternalPath && item.source !== "media_store" && item.source !== "saf");

      const strategy: DeleteStrategy = item.deleteStrategy || (
        item.junkType === "empty_folder" ? "manage_external_storage" :
        item.source === "media_store" ? "media_store" :
        item.source === "saf" ? "document_uri" :
        isExternalManaged ? "manage_external_storage" :
        "filesystem"
      );

      switch (strategy) {
        case "media_store":
          mediaStoreItems.push(item);
          break;
        case "document_uri":
          documentUriItems.push(item);
          break;
        case "filesystem":
          filesystemItems.push(item);
          break;
        case "manage_external_storage":
          manageExternalItems.push(item);
          break;
        case "unsupported":
        default:
          unsupportedItems.push(item);
          break;
      }
    }

    let permissionBlockedCount = unsupportedItems.length;

    // 1. MediaStore assets via Android ContentResolver / MediaLibrary
    // Rule: DO NOT fallback to File.delete() if Scoped Storage denies access
    if (mediaStoreItems.length > 0) {
      try {
        const mediaStoreIds = mediaStoreItems.map((i) => i.id);
        const ok = await MediaLibrary.deleteAssetsAsync(mediaStoreIds);
        if (!ok) {
          permissionBlockedCount += mediaStoreItems.length;
        }
      } catch (err) {
        console.warn("[DeleteCoordinator] MediaLibrary delete rejected or failed:", err);
        permissionBlockedCount += mediaStoreItems.length;
      }
    }

    // 2. Storage Access Framework documents via DocumentsContract
    for (const item of documentUriItems) {
      try {
        const ok = await SAFBridge.deleteDocument(item.uri);
        if (!ok) {
          permissionBlockedCount++;
        }
      } catch {
        permissionBlockedCount++;
      }
    }

    // 3. Native FileSystem (app cache, temporary files, internal app data)
    const fsPaths = filesystemItems.map((i) => i.path || i.uri).filter((p) => Boolean(p));
    if (fsPaths.length > 0) {
      try {
        await AndroidStorage.deleteNativeFiles(fsPaths);
      } catch (err) {
        console.warn("[DeleteCoordinator] Native filesystem delete error:", err);
        // Fallback for URIs using FileSystem.deleteAsync
        for (const item of filesystemItems) {
          try {
            await FileSystem.deleteAsync(item.uri, { idempotent: true });
          } catch {}
        }
      }
    }

    // 4. MANAGE_EXTERNAL_STORAGE required items
    if (manageExternalItems.length > 0) {
      const hasManagerAccess = AndroidStorage.isExternalStorageManager();
      if (hasManagerAccess) {
        const paths = manageExternalItems.map((i) => i.path || i.uri).filter(Boolean);
        try {
          await AndroidStorage.deleteNativeFiles(paths);
        } catch {}
      } else {
        permissionBlockedCount += manageExternalItems.length;
      }
    }

    // 5. Physical Post-Deletion Verification via StorageVerifier
    // Ensure that only items whose files NO LONGER EXIST on storage are marked deleted
    const { confirmedDeletedIds, remainingIds } = await StorageVerifier.verifyDeleted(items);

    let freedBytes = 0;
    const confirmedSet = new Set(confirmedDeletedIds);
    for (const item of items) {
      if (confirmedSet.has(item.id)) {
        freedBytes += item.sizeBytes;
      }
    }

    // Purge only physically verified deleted items from SQLite
    if (confirmedDeletedIds.length > 0) {
      StorageIndexService.deleteItemsByIds(confirmedDeletedIds);
      this.notify(confirmedDeletedIds);
    }

    return {
      requestedCount: items.length,
      deletedCount: confirmedDeletedIds.length,
      freedBytes,
      failedCount: remainingIds.length,
      permissionBlockedCount,
    };
  }
}

export const DeleteCoordinator = new DeleteCoordinatorImpl();
